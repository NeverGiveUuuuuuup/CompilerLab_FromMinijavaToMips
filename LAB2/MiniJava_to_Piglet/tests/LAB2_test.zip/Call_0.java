class Call_0{
	public static void main(String[] s){
		Call_0_A a;
		boolean b;
		a = new Call_0_A();
		b = a.f2(10);	
	}
} 
class Call_0_A{
	
	public boolean f2(int t){
		System.out.println(2);
		return true;
	}
	public int f1(){
		return 0;
	}
}