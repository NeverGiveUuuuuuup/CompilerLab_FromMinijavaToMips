class test{
    public static void main(String[] s){
        test_0 a;
		test_1 b;
		a = new test_0();
		System.out.println(a.f1());
		System.out.println(a.f0(1,2));
		System.out.println(a.f2());
		
		b = new test_1();
		System.out.println(b.f3());
		
		System.out.println(b.f2());
		System.out.println(b.f0(1,2));
		System.out.println(b.f1());
		
		a = new test_1();
		System.out.println(a.f1());
		System.out.println(a.f0(1,2));
		System.out.println(a.f2());
		
    }
}
class test_0{
	int a;
	int b;
	int c;
	public int f0(int x, int y){
		int a;
		a = x+y;
		return a;
	}
	public int f1(){
		a=1;
		b=2;
		c=3;
		return a;
	}
	public int f2(){
		return 2;
	}
}
class test_1 extends test_0{
	public int f3(){
		return 3;
	}
}

